<!DOCTYPE html>
<html>
<head>
    <title>Fisher Price - My First Model View Controller</title>
</head>
<body>
<h1>Hello From My View!</h1>
<ul>
    <li>User ID: <?php echo $userid;?></li>
    <li>First Name: <?php echo $first;?></li>
    <li>Last Name: <?php echo $last;?></li>
    <li>Email: <?php echo $email;?></li>
    <li>Role: <?php echo $role;?></li>


</ul>
</body>
</html>