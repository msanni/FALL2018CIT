<?php
include('views/elements/header.php');?>
<div class="container">
	<div class="page-header">
    <h1>Hello From the View</h1>
  </div>
    <div class="alert alert-success">
        <?php echo $message;?>
    </div>


</div>
<?php include('views/elements/footer.php');?>
