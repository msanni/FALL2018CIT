<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:23721/final1/');
//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'msanni');
define('DB_PASS', '1stAccount');
define('DB_NAME', 'msanni_db');

define('REQFIELD', '<font color="#FF0000">*</font>');
